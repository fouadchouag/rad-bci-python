# -*- coding: utf-8 -*-
"""
MNESampleLoader — charge le dataset d'exemple MNE (sample_audvis_raw.fif)
→ Avec section Paramètres pliable (fermée par défaut)
"""
from typing import Optional
import os

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QDoubleSpinBox, QCheckBox, QFrame, QLineEdit, QComboBox
)
from rx.subject import BehaviorSubject
from core.node_base import BasePlugin

try:
    import mne
    HAVE_MNE = True
except Exception:
    HAVE_MNE = False


# ---------------------- Section pliable autonome ----------------------
class CollapsibleSection(QWidget):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self._base_title = title
        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(0, 0, 0, 0)
        self._root.setSpacing(4)

        self._btn = QPushButton()
        self._btn.setCheckable(True)
        self._btn.setChecked(False)  # unchecked = collapsed au démarrage
        self._btn.setStyleSheet(
            "QPushButton {"
            " text-align: left; padding:6px 8px; font-weight:600;"
            " border:1px solid #ccc; border-radius:6px; background:#f7f7f7;"
            "}"
        )
        self._btn.toggled.connect(self._on_toggled)
        self._root.addWidget(self._btn)

        self._content = QWidget()
        self._content.setVisible(False)
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(10, 8, 10, 8)
        self._content_layout.setSpacing(6)
        self._root.addWidget(self._content)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color:#ddd;")
        self._root.addWidget(line)

        self._update_arrow()

    def _on_toggled(self, checked: bool):
        self._content.setVisible(checked)
        self._update_arrow()

    def _update_arrow(self):
        arrow = "▼ " if self._btn.isChecked() else "▶ "
        self._btn.setText(arrow + self._base_title)

    def content_layout(self) -> QVBoxLayout:
        return self._content_layout

    def add_content_widget(self, w: QWidget):
        self._content_layout.addWidget(w)

    def set_collapsed(self, collapsed: bool):
        self._btn.setChecked(not collapsed)
        self._content.setVisible(not collapsed)
        self._update_arrow()


class MNESampleLoader(BasePlugin):
    help = {
        'gotchas': ['Télécharge le dataset au 1er appel (via mne.datasets.sample).'],
        'inputs': {},
        'outputs': {'raw': 'mne.Raw', 'status': 'str'},
        'parameters': [
            {'name': 'duration_s', 'type': 'float', 'default': 60.0, 'unit': 's',
             'desc': 'Durée à garder'},
            {'name': 'preload', 'type': 'bool', 'default': True,
             'desc': 'Précharger les données en mémoire'}
        ],
        'summary': "MNESampleLoader — dataset d'exemple MNE (FIF)",
        'usage': "Placez-le en début de pipeline; connectez `raw` vers MNE Viewer 2D."
    }

    name = "MNESampleLoader"
    language = "Python"
    category = "Input Nodes"

    def setup(self):
        self.outputs["raw"] = BehaviorSubject(None)
        self.outputs["status"] = BehaviorSubject("")
        self._widget: Optional[QWidget] = None
        self._dur_s = 60.0
        self._preload = True

    def build_widget(self) -> QWidget:
        w = QWidget()
        root = QVBoxLayout(w)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)

        title = QLabel("MNE Sample Loader (FIF)")
        title.setStyleSheet("font-weight:600;font-size:14px;")
        root.addWidget(title)

        if not HAVE_MNE:
            warn = QLabel("MNE n'est pas installé. Faites `pip install mne`.")
            warn.setStyleSheet("color:#b00")
            warn.setWordWrap(True)
            root.addWidget(warn)
            self._widget = w
            return w

        # ---------- Section pliable: Paramètres (fermée par défaut) ----------
        sec = CollapsibleSection("Paramètres")
        sec.set_collapsed(True)

        # Ligne durée + preload
        row1 = QWidget()
        r1 = QHBoxLayout(row1); r1.setContentsMargins(0, 0, 0, 0); r1.setSpacing(6)
        r1.addWidget(QLabel("Durée gardée (s)"))
        self._sp_dur = QDoubleSpinBox()
        self._sp_dur.setRange(0.0, 600.0)
        self._sp_dur.setDecimals(1)
        self._sp_dur.setSingleStep(1.0)
        self._sp_dur.setValue(self._dur_s)
        r1.addWidget(self._sp_dur)
        self._chk_preload = QCheckBox("Précharger")
        self._chk_preload.setChecked(self._preload)
        r1.addWidget(self._chk_preload)
        r1.addStretch(1)

        # Bouton Charger
        row_btn = QWidget()
        rbtn = QHBoxLayout(row_btn); rbtn.setContentsMargins(0, 0, 0, 0); rbtn.setSpacing(6)
        self._btn = QPushButton("Charger")
        self._btn.clicked.connect(self._on_load)
        rbtn.addStretch(1)
        rbtn.addWidget(self._btn)

        # Ajout au contenu pliable
        sec.add_content_widget(row1)
        sec.add_content_widget(row_btn)

        # Status (toujours visible)
        self._lbl = QLabel("")
        self._lbl.setStyleSheet("color:#666")

        root.addWidget(sec)
        root.addWidget(self._lbl)

        self._widget = w
        return w

    def _set_status(self, msg: str):
        self.outputs["status"].on_next(msg)
        if getattr(self, "_lbl", None) is not None:
            self._lbl.setText(msg)

    def _on_load(self):
        if not HAVE_MNE:
            self._set_status("MNE non dispo")
            return
        try:
            self._dur_s = float(self._sp_dur.value())
            self._preload = bool(self._chk_preload.isChecked())

            # 1) chemin du dataset sample (télécharge si absent)
            data_dir = mne.datasets.sample.data_path()
            fif_path = os.path.join(data_dir, "MEG", "sample", "sample_audvis_raw.fif")
            if not os.path.exists(fif_path):
                raise FileNotFoundError("Fichier FIF introuvable après data_path().")

            # 2) lire le Raw FIF
            raw = mne.io.read_raw_fif(fif_path, preload=self._preload, verbose=False)

            # 3) Crop si demandé
            if self._dur_s and self._dur_s > 0:
                try:
                    raw.crop(tmin=0.0, tmax=self._dur_s)
                except TypeError:
                    raw.crop(tmax=self._dur_s)

            # Si pas preload mais nécessaire pour le viewer, on force le chargement
            if self._preload is False:
                try:
                    raw.load_data()
                except Exception:
                    pass

            # 4) sortie
            self.outputs["raw"].on_next(raw)
            nchan = len(raw.ch_names)
            sf = float(raw.info.get('sfreq', 0.0))
            dur = raw.n_times / sf if sf else float('nan')
            self._set_status(
                f"Chargé: {os.path.basename(fif_path)} | Canaux: {nchan} | "
                f"sf: {sf:.2f} Hz | durée: {dur:.1f} s"
            )
        except Exception as e:
            self._set_status(f"Erreur: {e}")

    def execute(self, *args, **kwargs):
        try:
            if getattr(self, "_lbl", None) is not None and self._lbl.text() == "":
                self._set_status("Prêt. Ouvrez ‘Paramètres’ puis cliquez ‘Charger’.")
        except Exception:
            pass
