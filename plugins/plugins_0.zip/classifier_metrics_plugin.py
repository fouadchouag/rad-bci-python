# plugins/classifier_metrics_plugin.py
# -*- coding: utf-8 -*-

import numpy as np
from rx.subject import BehaviorSubject
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSpinBox, QTableWidget, QTableWidgetItem,
    QLayout, QSizePolicy, QToolButton
)
from core.node_base import BasePlugin

try:
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import StratifiedKFold, cross_val_predict, cross_val_score
    from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False


class _CollapsibleSection(QWidget):
    def __init__(self, title="Paramètres", content: QWidget = None, collapsed=True, parent=None):
        super().__init__(parent)
        self._btn = QToolButton(text=title, checkable=True, autoRaise=True)
        self._btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        self._wrap = QWidget()
        self._wrap_l = QVBoxLayout(self._wrap)
        self._wrap_l.setContentsMargins(0, 0, 0, 0)
        self._wrap_l.setSpacing(0)
        self._content = content or QWidget()
        self._content.setStyleSheet("background: transparent;")
        self._wrap_l.addWidget(self._content)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(4)
        root.addWidget(self._btn)
        root.addWidget(self._wrap)

        self._btn.toggled.connect(self._on_toggled)
        self._btn.setChecked(not collapsed)
        self._on_toggled(self._btn.isChecked())

    def _poke_ancestors(self):
        w = self
        while w is not None:
            if w.layout():
                w.layout().invalidate()
            w.adjustSize()
            w.updateGeometry()
            w = w.parentWidget()

    def _on_toggled(self, expanded: bool):
        self._btn.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._wrap.setVisible(expanded)
        if expanded:
            self.setMaximumHeight(16777215)
            self.setMinimumHeight(0)
            self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
            self._wrap.setMaximumHeight(16777215)
            self._wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        else:
            header_h = self._btn.sizeHint().height() + 6
            self._wrap.setMaximumHeight(0)
            self._wrap.setMinimumHeight(0)
            self._wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.setMaximumHeight(header_h)
            self.setMinimumHeight(header_h)
            self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self._poke_ancestors()


class ClassifierMetricsPlugin(BasePlugin):
    help = help = { 'gotchas': ['Model-version mismatch can reduce accuracy.'],
  'inputs': {'features': 'array/dict', 'model': 'trained model'},
  'outputs': {'pred': 'labels', 'proba': 'optional probabilities'},
  'parameters': [ { 'default': 0.5,
                    'desc': 'Decision threshold (if applicable)',
                    'name': 'threshold',
                    'type': 'float'}],
  'summary': 'Évalue un dataset publié par EEGClassifier (X/y) via CV.',
  'usage': 'Connect features and a compatible model.'}

    """
    Évalue un dataset publié par EEGClassifier (X/y) via CV.
    Entrées:
      - dataset: dict {X: np.ndarray[N, d], y: np.ndarray[N], y_names: [str,str], ...}
      - config_in (dict, optionnel)
      - metrics_conf (dict, optionnel)

    UI (repliable):
      - Folds (2..10), bouton Evaluate (CV)
      - Statut, métriques, matrice de confusion

    Sorties:
      - (UI only) + config_out (dict)
    """
    name = "ClassifierMetrics"
    language = "Python"
    category = "ML"

    def setup(self):
        self.inputs["dataset"] = BehaviorSubject(None)
        self.inputs["config_in"] = BehaviorSubject(None)
        self.inputs["metrics_conf"] = BehaviorSubject(None)

        self.outputs["config_out"] = BehaviorSubject(None)

        self._dataset = None
        self._lbl_status = None
        self._lbl_metrics = None
        self._table_cm = None
        self._spn_folds = None
        self._btn_eval = None

        self._folds = 5

    # ----- config -----
    def export_config(self) -> dict:
        return {"folds": int(self._folds)}

    def import_config(self, cfg: dict):
        if not isinstance(cfg, dict): return
        if "folds" in cfg:
            try:
                self._folds = int(cfg["folds"])
                if self._spn_folds: self._spn_folds.setValue(self._folds)
            except Exception:
                pass
        self._emit_config()

    def _emit_config(self):
        try:
            self.outputs["config_out"].on_next(self.export_config())
        except Exception:
            pass

    def build_widget(self):
        w = QWidget()
        root = QVBoxLayout(w)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)
        root.setSizeConstraint(QLayout.SetMinAndMaxSize)
        w.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)

        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(8, 8, 8, 8)
        pv.setSpacing(6)

        row = QHBoxLayout()
        row.addWidget(QLabel("Folds:"))
        self._spn_folds = QSpinBox()
        self._spn_folds.setRange(2, 10)
        self._spn_folds.setValue(self._folds)
        self._spn_folds.valueChanged.connect(lambda v: self._on_set_folds(int(v)))
        row.addWidget(self._spn_folds)

        self._btn_eval = QPushButton("Evaluate (CV)")
        self._btn_eval.clicked.connect(self._on_evaluate)
        row.addWidget(self._btn_eval)
        row.addStretch(1)
        pv.addLayout(row)

        self._lbl_status = QLabel("Waiting dataset")
        pv.addWidget(self._lbl_status)

        self._lbl_metrics = QLabel("No metrics yet")
        pv.addWidget(self._lbl_metrics)

        self._table_cm = QTableWidget(2, 2)
        self._table_cm.setHorizontalHeaderLabels(["Pred A", "Pred B"])
        self._table_cm.setVerticalHeaderLabels(["True A", "True B"])
        pv.addWidget(self._table_cm)

        sec = _CollapsibleSection("Paramètres & Résultats", panel, collapsed=True)
        root.addWidget(sec)

        # push initial config
        self._emit_config()
        return w

    def _on_set_folds(self, v: int):
        self._folds = int(v)
        self._emit_config()

    def execute(self, **kwargs):
        # merge config
        merged = {}
        c1 = kwargs.get("config_in"); c2 = kwargs.get("metrics_conf")
        if isinstance(c1, dict): merged.update(c1)
        if isinstance(c2, dict): merged.update(c2)
        if merged: self.import_config(merged)

        ds = kwargs.get("dataset", None)
        self._dataset = ds

        if ds is None:
            if self._lbl_status:
                self._lbl_status.setText("Waiting dataset")
            self._reset_metrics_ui(("A", "B"))
            return {}

        X = ds.get("X", None)
        y = ds.get("y", None)
        y_names = ds.get("y_names", ["A", "B"])
        if not isinstance(y_names, (list, tuple)) or len(y_names) < 2:
            y_names = ["A", "B"]
        y_names = list(y_names[:2])

        if self._table_cm:
            self._table_cm.setHorizontalHeaderLabels(y_names)
            self._table_cm.setVerticalHeaderLabels(y_names)

        if X is None or y is None or len(np.atleast_1d(y)) == 0:
            if self._lbl_status:
                self._lbl_status.setText("Empty dataset")
            self._reset_metrics_ui(y_names)
            return {}

        try:
            X = np.asarray(X, dtype=float)
            y = np.asarray(y, dtype=int)
        except Exception:
            if self._lbl_status:
                self._lbl_status.setText("Invalid dataset (types)")
            self._reset_metrics_ui(y_names)
            return {}

        N = int(X.shape[0]) if X is not None else 0
        d = int(X.shape[1]) if (X is not None and X.ndim == 2) else 0
        n0 = int(np.sum(y == 0))
        n1 = int(np.sum(y == 1))
        if self._lbl_status:
            self._lbl_status.setText(f"Dataset ready | N={N}, d={d} | {y_names[0]}={n0} / {y_names[1]}={n1}")

        self._reset_metrics_ui(y_names)
        return {}

    # ----------------- actions -----------------
    def _on_evaluate(self):
        if not SKLEARN_OK:
            if self._lbl_metrics:
                self._lbl_metrics.setText("Install scikit-learn: pip install scikit-learn")
            return
        ds = self._dataset or {}
        X, y = ds.get("X", None), ds.get("y", None)
        y_names = ds.get("y_names", ["A", "B"])
        if not isinstance(y_names, (list, tuple)) or len(y_names) < 2:
            y_names = ["A", "B"]
        y_names = list(y_names[:2])

        if X is None or y is None:
            if self._lbl_metrics:
                self._lbl_metrics.setText("No dataset.")
            self._reset_metrics_ui(y_names)
            return

        try:
            X = np.asarray(X, dtype=float)
            y = np.asarray(y, dtype=int)
        except Exception as e:
            if self._lbl_metrics:
                self._lbl_metrics.setText(f"Dataset error: {e}")
            self._reset_metrics_ui(y_names)
            return

        if len(y) < 6 or len(set(y)) < 2:
            if self._lbl_metrics:
                self._lbl_metrics.setText("Need more samples (>=6) and both classes.")
            self._reset_metrics_ui(y_names)
            return

        counts = [np.sum(y == 0), np.sum(y == 1)]
        max_folds = int(max(2, min(counts)))
        n_folds_req = int(self._folds)
        n_folds = min(n_folds_req, max_folds)

        try:
            pipe = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
            cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)

            acc_scores = cross_val_score(pipe, X, y, cv=cv, scoring="accuracy")
            acc_mean, acc_std = float(np.mean(acc_scores)), float(np.std(acc_scores))

            y_pred = cross_val_predict(pipe, X, y, cv=cv)
            cm = confusion_matrix(y, y_pred, labels=[0, 1])
            prec, rec, f1, _ = precision_recall_fscore_support(
                y, y_pred, labels=[0, 1], zero_division=0
            )

            if self._lbl_metrics:
                self._lbl_metrics.setText(
                    f"CV({n_folds}) Acc: {acc_mean:.2%} ± {acc_std:.2%}   |   "
                    f"Precision: {y_names[0]}={prec[0]:.2f}, {y_names[1]}={prec[1]:.2f}   |   "
                    f"Recall: {y_names[0]}={rec[0]:.2f}, {y_names[1]}={rec[1]:.2f}"
                )

            if self._table_cm:
                self._table_cm.setRowCount(2)
                self._table_cm.setColumnCount(2)
                self._table_cm.setHorizontalHeaderLabels(y_names)  # Pred
                self._table_cm.setVerticalHeaderLabels(y_names)    # True
                for i in range(2):
                    for j in range(2):
                        item = QTableWidgetItem(str(int(cm[i, j]))); item.setTextAlignment(int(Qt.AlignCenter))
                        self._table_cm.setItem(i, j, item)
                self._table_cm.resizeColumnsToContents()

        except Exception as e:
            if self._lbl_metrics:
                self._lbl_metrics.setText(f"Eval error: {e}")

    def _reset_metrics_ui(self, y_names=("A", "B")):
        if self._lbl_metrics:
            self._lbl_metrics.setText("No metrics yet")
        if self._table_cm:
            self._table_cm.setRowCount(2)
            self._table_cm.setColumnCount(2)
            self._table_cm.setHorizontalHeaderLabels(list(y_names))
            self._table_cm.setVerticalHeaderLabels(list(y_names))
            for i in range(2):
                for j in range(2):
                    self._table_cm.setItem(i, j, QTableWidgetItem(""))